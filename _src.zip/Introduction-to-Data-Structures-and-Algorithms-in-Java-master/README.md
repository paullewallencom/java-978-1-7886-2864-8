## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/introduction-to-data-structures-algorithms-in-java-video/9781788628648)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Introduction-to-Data-Structures-and-Algorithms-in-Java
Introduction to Data Structures and Algorithms in Java, published by Packt
