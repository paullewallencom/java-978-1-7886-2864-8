This repository is meant for hosting the solutions to assignments for Data Structure & Algorithms course by DIZAUVI(Raghavendra Dikshit)
All the assignments/exercises are available on the wiki page.
Please make sure that you attempt the assignments before taking a look at the code/solutions.

