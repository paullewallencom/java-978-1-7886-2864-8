package chapter2;

public interface UserDao {
	public User findUserByEmail(String email);
}
