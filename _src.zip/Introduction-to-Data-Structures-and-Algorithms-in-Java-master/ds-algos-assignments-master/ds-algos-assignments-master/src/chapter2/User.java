package chapter2;

public class User {
	private String email;
	private String encryptedPassword;
	private String firstName;
	
}
